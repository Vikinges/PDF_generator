const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Avoid 404 for favicon requests from browsers
app.get('/favicon.ico', (req, res) => res.status(204).end());

app.get('/', (req, res) => {
  res.send(`<h2>Service 1</h2><p>This is demo service 1 running in its own container.</p><p><a href=\"/\">Back</a></p>`);
});

// Health endpoint for orchestration / hub
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'service1', uptime: process.uptime(), now: new Date().toISOString() });
});

app.listen(PORT, () => console.log(`Service1 on ${PORT}`));
